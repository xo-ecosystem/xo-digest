# Task Namespaces

Details about task namespaces.